# Electricity Bill Analysis

![Python](https://img.shields.io/badge/python-3.10%2B-blue) ![License](https://img.shields.io/badge/license-MIT-green)

An end-to-end data analysis project on household electricity usage and billing: it explores consumption
patterns, **flags abnormal bills**, **predicts monthly bills**, and **forecasts demand** for the next six months.

## Business questions
1. How do consumption and bills change by month, season and property type?
2. How do temperature, household size, appliances and floor area drive usage?
3. Which bills look abnormal (meter faults, leaks, theft)?
4. Can we predict a household's bill, and forecast future demand?

## Highlights (synthetic data, 200 households x 36 months = 7,200 records)
| Metric | Result |
|---|---|
| Average usage / bill | ~207 kWh / ~35.1 per month |
| Peak vs lowest month | May (~233 kWh) vs November (~187 kWh) |
| Anomalous bills flagged | 72 (1% contamination setting) |
| Best bill model | Gradient Boosting, R² ~0.83, MAE ~2.3 |
| Demand forecast backtest | ~1.3% MAPE |

![Monthly trend](reports/figures/01_monthly_trend.png)
![Tariff effect](reports/figures/05_tariff_effect.png)
![Forecast](reports/figures/09_forecast.png)

> The bundled dataset is **synthetic**; results demonstrate the method and are not real-world findings.

## Project structure
```
electricity-bill-analysis/
├── main.py                  # run the whole pipeline
├── src/
│   ├── config.py            # paths, constants, tariff tiers
│   ├── data_generation.py   # synthetic data + tariff calculator
│   ├── preprocessing.py     # cleaning + feature engineering
│   ├── eda.py               # charts and summary tables
│   ├── anomaly.py           # Isolation Forest anomaly detection
│   └── modeling.py          # bill regression + consumption forecast
├── notebooks/
│   └── electricity_bill_analysis.ipynb   # narrative walkthrough (pre-executed)
├── data/                    # raw and cleaned CSVs
├── reports/                 # summary_report.txt, flagged_anomalies.csv, figures/
├── tests/                   # pytest unit tests
├── .github/workflows/ci.yml # runs tests + pipeline on every push
└── push_to_github.sh        # one-command upload
```

## Quick start
```bash
git clone https://github.com/<your-username>/electricity-bill-analysis.git
cd electricity-bill-analysis
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python main.py                    # run the full pipeline
pytest                            # run tests
jupyter notebook notebooks/       # open the walkthrough
```

### Use your own data
```bash
python main.py --data path/to/bills.csv
```
Required columns:
`household_id, month (YYYY-MM-DD), units_kwh, bill_amount, avg_temp_c, household_size, property_type, num_appliances, area_sqm`

### Configure the tariff
Edit `src/config.py` (used by the synthetic data generator):
```python
TARIFF_TIERS = [(100, 0.10), (200, 0.15), (float("inf"), 0.22)]
FIXED_CHARGE = 5.0
TAX_RATE = 0.075
```

## Methodology
**Cleaning:** duplicates and non-positive readings removed; dates parsed; numeric gaps filled with the median.

**Features:** year, month, season, cost per kWh, kWh per person, kWh per m², month-over-month change.

**Anomaly detection:** Isolation Forest on usage, usage intensity and temperature; flagged bills exported to `reports/flagged_anomalies.csv`.

**Bill prediction:** Linear Regression, Random Forest and Gradient Boosting trained on normal bills with a 75/25 split; compared on R², MAE and RMSE.

**Forecasting:** seasonal-naive (same month last year) scaled by average year-over-year growth, backtested on the final six months.

## Outputs
- `reports/summary_report.txt`: full numeric results
- `reports/flagged_anomalies.csv`: bills to inspect
- `reports/figures/`: 9 charts
- `data/bills_clean.csv`: model-ready dataset

## Limitations & next steps
- Synthetic data: validate on real smart-meter data.
- Try SARIMA / Prophet for forecasting; add holiday and price effects.
- Add a tariff-switching savings simulator and a Streamlit dashboard.

## License
MIT
