"""Run the full electricity bill analysis pipeline.

    python main.py                      # synthetic data
    python main.py --data my_bills.csv  # your own data
"""
import argparse

import pandas as pd

from src import anomaly, eda, modeling
from src.config import CLEAN_DATA_PATH, DATA_DIR, RAW_DATA_PATH, REPORTS_DIR
from src.data_generation import generate_synthetic_data
from src.preprocessing import prepare


def write_report(df: pd.DataFrame, summary: dict, results: dict, forecast: pd.DataFrame) -> str:
    monthly = df.groupby("month_num")["units_kwh"].mean()
    lines = ["ELECTRICITY BILL ANALYSIS - SUMMARY REPORT", "=" * 44,
             f"Records analysed        : {len(df):,}",
             f"Households              : {df['household_id'].nunique():,}",
             f"Period                  : {df['month'].min():%b %Y} to {df['month'].max():%b %Y}",
             f"Average monthly usage   : {df['units_kwh'].mean():.1f} kWh",
             f"Average monthly bill    : {df['bill_amount'].mean():.2f}",
             f"Peak month (avg usage)  : month {monthly.idxmax()} ({monthly.max():.1f} kWh)",
             f"Lowest month (avg usage): month {monthly.idxmin()} ({monthly.min():.1f} kWh)",
             f"Anomalous bills flagged : {int(df['is_anomaly'].sum())}", "",
             "By property type:", summary["by_property"].to_string(), "",
             "By season:", summary["by_season"].to_string(), "",
             "Bill prediction models:"]
    for name, r in results.items():
        if name != "best_model":
            lines.append(f"  {name:<20} R2={r['r2']:.3f} | MAE={r['mae']:.2f} | RMSE={r['rmse']:.2f}")
    lines += [f"  Best model: {results['best_model']}", "",
              f"Forecast backtest MAPE: {forecast.attrs['mape']:.1f}%",
              "Next-6-month forecast (avg kWh per household):", forecast["forecast_kwh"].round(1).to_string()]
    text = "\n".join(lines)
    (REPORTS_DIR / "summary_report.txt").write_text(text)
    return text


def main() -> None:
    parser = argparse.ArgumentParser(description="Electricity bill analysis")
    parser.add_argument("--data", help="Path to a bills CSV")
    args = parser.parse_args()

    DATA_DIR.mkdir(exist_ok=True)
    REPORTS_DIR.mkdir(exist_ok=True)
    if args.data:
        raw = pd.read_csv(args.data, parse_dates=["month"])
    else:
        raw = generate_synthetic_data()
        raw.to_csv(RAW_DATA_PATH, index=False)
    df = prepare(raw)
    summary = eda.run_all(df)
    df = anomaly.detect_anomalies(df)
    df.to_csv(CLEAN_DATA_PATH, index=False)
    results = modeling.train_bill_models(df)
    forecast = modeling.forecast_consumption(df)
    print(write_report(df, summary, results, forecast))


if __name__ == "__main__":
    main()
