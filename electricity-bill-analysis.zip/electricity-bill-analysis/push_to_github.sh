#!/usr/bin/env bash
# Upload this project to GitHub.
# Option A (recommended): GitHub CLI   ->  ./push_to_github.sh
# Option B: existing empty repo URL    ->  ./push_to_github.sh https://github.com/<user>/<repo>.git
set -e
REPO_NAME="electricity-bill-analysis"

[ -d .git ] || git init -b main
git add .
git commit -m "Add electricity bill analysis project" || true

if [ -n "$1" ]; then
  git remote remove origin 2>/dev/null || true
  git remote add origin "$1"
  git push -u origin main
elif command -v gh >/dev/null 2>&1; then
  gh auth status >/dev/null 2>&1 || gh auth login
  gh repo create "$REPO_NAME" --public --source=. --remote=origin --push \
    --description "Electricity bill analysis: EDA, anomaly detection, bill prediction and demand forecasting"
else
  echo "Install GitHub CLI (https://cli.github.com) or pass an empty repo URL as the first argument."
  exit 1
fi
echo "Done. Your repo is live on GitHub."
