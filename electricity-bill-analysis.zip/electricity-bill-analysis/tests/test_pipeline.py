import pytest

from src.anomaly import detect_anomalies
from src.data_generation import compute_bill, generate_synthetic_data
from src.preprocessing import prepare, season_of


@pytest.fixture(scope="module")
def df():
    return prepare(generate_synthetic_data(n_households=30, start="2024-01-01", end="2025-12-01"))


def test_tariff_tiers():
    # 100 kWh @0.10 = 10, +5 fixed = 15, x1.075 tax
    assert compute_bill(100) == pytest.approx(16.13, abs=0.01)
    # 250 kWh: 100*0.10 + 100*0.15 + 50*0.22 = 36, +5 = 41, x1.075
    assert compute_bill(250) == pytest.approx(44.08, abs=0.01)


def test_bill_increases_with_usage():
    assert compute_bill(300) > compute_bill(150) > compute_bill(50)


def test_season_mapping():
    assert season_of(3) == "Hot" and season_of(7) == "Rainy" and season_of(12) == "Harmattan/Cool"


def test_features_present(df):
    for col in ["year", "season", "cost_per_kwh", "kwh_per_person", "kwh_per_sqm", "mom_change_pct"]:
        assert col in df.columns
    assert (df["units_kwh"] > 0).all()


def test_anomaly_flag(df):
    out = detect_anomalies(df)
    assert out["is_anomaly"].dtype == bool
    assert 0 < out["is_anomaly"].sum() < len(out) * 0.05
