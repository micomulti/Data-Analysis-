"""Exploratory analysis: consumption patterns, seasonality and drivers."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from .config import FIG_DIR

sns.set_theme(style="whitegrid")


def _save(name: str) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(FIG_DIR / name, dpi=140)
    plt.close()


def summary_tables(df: pd.DataFrame) -> dict:
    return {
        "by_property": df.groupby("property_type")[["units_kwh", "bill_amount"]].mean().round(2),
        "by_season": df.groupby("season")[["units_kwh", "bill_amount"]].mean().round(2),
        "by_household_size": df.groupby("household_size")["units_kwh"].mean().round(1),
        "by_year": df.groupby("year")[["units_kwh", "bill_amount"]].mean().round(2),
    }


def plot_monthly_trend(df: pd.DataFrame) -> None:
    monthly = df.groupby("month")[["units_kwh", "bill_amount"]].mean()
    fig, ax1 = plt.subplots(figsize=(12, 4.5))
    ax1.plot(monthly.index, monthly["units_kwh"], color="#2E86AB", marker="o", ms=3)
    ax1.set_ylabel("Average kWh", color="#2E86AB")
    ax2 = ax1.twinx()
    ax2.plot(monthly.index, monthly["bill_amount"], color="#D1495B", marker="s", ms=3)
    ax2.set_ylabel("Average bill", color="#D1495B")
    ax2.grid(False)
    plt.title("Average Monthly Consumption and Bill")
    _save("01_monthly_trend.png")


def plot_seasonality(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(14, 4.8))
    sns.boxplot(data=df, x="month_num", y="units_kwh", color="#8FC1D4", ax=axes[0])
    axes[0].set_title("Consumption by Calendar Month")
    axes[0].set_xlabel("Month")
    sns.boxplot(data=df, x="property_type", y="bill_amount", hue="property_type",
                palette="Set2", legend=False, ax=axes[1])
    axes[1].set_title("Bill Amount by Property Type")
    _save("02_seasonality_property.png")


def plot_drivers(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(14, 4.8))
    sns.scatterplot(data=df.sample(min(3000, len(df)), random_state=1), x="avg_temp_c", y="units_kwh",
                    hue="property_type", alpha=0.5, ax=axes[0])
    axes[0].set_title("Temperature vs Consumption")
    sns.barplot(data=df, x="household_size", y="units_kwh", color="#EDAE49", ax=axes[1])
    axes[1].set_title("Average kWh by Household Size")
    _save("03_drivers.png")


def plot_correlation(df: pd.DataFrame) -> None:
    cols = ["units_kwh", "bill_amount", "avg_temp_c", "household_size", "num_appliances", "area_sqm", "cost_per_kwh"]
    plt.figure(figsize=(8, 6.5))
    sns.heatmap(df[cols].corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Correlation Matrix")
    _save("04_correlation.png")


def plot_tariff_effect(df: pd.DataFrame) -> None:
    """Show how the tiered tariff makes the effective price per kWh rise with usage."""
    plt.figure(figsize=(8, 4.8))
    sns.scatterplot(data=df.sample(min(3000, len(df)), random_state=1), x="units_kwh",
                    y="cost_per_kwh", hue="property_type", alpha=0.5)
    plt.title("Effective Cost per kWh vs Usage (Tiered Tariff)")
    _save("05_tariff_effect.png")


def run_all(df: pd.DataFrame) -> dict:
    plot_monthly_trend(df)
    plot_seasonality(df)
    plot_drivers(df)
    plot_correlation(df)
    plot_tariff_effect(df)
    return summary_tables(df)
