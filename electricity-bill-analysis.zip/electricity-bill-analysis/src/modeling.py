"""Bill prediction (regression) and consumption forecasting (time series)."""
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

from .config import FIG_DIR, RANDOM_STATE, REPORTS_DIR, TEST_SIZE

FEATURES = ["avg_temp_c", "household_size", "num_appliances", "area_sqm", "month_num"]


def build_matrix(df: pd.DataFrame):
    X = pd.get_dummies(df[FEATURES + ["property_type"]], columns=["property_type"], drop_first=True)
    return X, df["bill_amount"]


def train_bill_models(df: pd.DataFrame) -> dict:
    """Train on normal bills only (anomalies excluded) and compare three regressors."""
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    clean = df[~df["is_anomaly"]] if "is_anomaly" in df else df
    X, y = build_matrix(clean)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE)

    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=200, min_samples_leaf=3,
                                               random_state=RANDOM_STATE, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=250, max_depth=3, learning_rate=0.08,
                                                       random_state=RANDOM_STATE),
    }
    results, fitted = {}, {}
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.8))
    for ax, (name, model) in zip(axes, models.items()):
        model.fit(X_tr, y_tr)
        pred = model.predict(X_te)
        results[name] = {"r2": r2_score(y_te, pred), "mae": mean_absolute_error(y_te, pred),
                         "rmse": float(np.sqrt(mean_squared_error(y_te, pred)))}
        fitted[name] = model
        ax.scatter(y_te, pred, alpha=0.3, s=8, color="#2E86AB")
        ax.plot([y_te.min(), y_te.max()], [y_te.min(), y_te.max()], "r--")
        ax.set_title(f"{name}\nR2={results[name]['r2']:.3f}, MAE={results[name]['mae']:.2f}")
        ax.set_xlabel("Actual bill"); ax.set_ylabel("Predicted bill")
    plt.tight_layout(); plt.savefig(FIG_DIR / "07_prediction.png", dpi=140); plt.close()

    best = max(results, key=lambda k: results[k]["r2"])
    if hasattr(fitted[best], "feature_importances_"):
        pd.Series(fitted[best].feature_importances_, index=X.columns).sort_values().plot.barh(
            figsize=(8, 4.5), color="#2E86AB")
        plt.title(f"Feature Importance ({best})")
        plt.tight_layout(); plt.savefig(FIG_DIR / "08_feature_importance.png", dpi=140); plt.close()
    joblib.dump({"model": fitted[best], "columns": list(X.columns)}, REPORTS_DIR / "best_bill_model.joblib")
    results["best_model"] = best
    return results


def forecast_consumption(df: pd.DataFrame, horizon: int = 6) -> pd.DataFrame:
    """Forecast portfolio-average monthly kWh using a seasonal-naive + trend model.

    Forecast = same month last year x (1 + average year-over-year growth). Validated by
    backtesting on the final `horizon` months.
    """
    series = df.groupby("month")["units_kwh"].mean().asfreq("MS")
    yoy = (series / series.shift(12) - 1).dropna()
    growth = float(yoy.iloc[:-horizon].mean()) if len(yoy) > horizon else 0.0

    train, test = series.iloc[:-horizon], series.iloc[-horizon:]
    backtest = pd.Series([train.get(m - pd.DateOffset(years=1), np.nan) * (1 + growth) for m in test.index],
                         index=test.index)
    mape = float((abs(backtest - test) / test).mean() * 100)

    future_idx = pd.date_range(series.index[-1] + pd.DateOffset(months=1), periods=horizon, freq="MS")
    future = pd.Series([series.get(m - pd.DateOffset(years=1), np.nan) * (1 + growth) for m in future_idx],
                       index=future_idx)

    plt.figure(figsize=(12, 4.5))
    plt.plot(series.index, series, label="Actual", color="#2E86AB")
    plt.plot(backtest.index, backtest, "--", label=f"Backtest (MAPE {mape:.1f}%)", color="#EDAE49")
    plt.plot(future.index, future, "o-", label=f"Forecast (+{horizon} months)", color="#D1495B")
    plt.ylabel("Average kWh"); plt.title("Consumption Forecast"); plt.legend()
    plt.tight_layout(); plt.savefig(FIG_DIR / "09_forecast.png", dpi=140); plt.close()

    out = future.rename("forecast_kwh").to_frame()
    out.attrs["mape"] = mape
    return out
