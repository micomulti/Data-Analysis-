"""Anomaly detection for abnormal bills."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.ensemble import IsolationForest

from .config import ANOMALY_PATH, FIG_DIR, RANDOM_STATE

FEATURES = ["units_kwh", "kwh_per_sqm", "kwh_per_person", "avg_temp_c"]


def detect_anomalies(df: pd.DataFrame, contamination: float = 0.01) -> pd.DataFrame:
    df = df.copy()
    iso = IsolationForest(contamination=contamination, random_state=RANDOM_STATE)
    df["is_anomaly"] = iso.fit_predict(df[FEATURES]) == -1

    FIG_DIR.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(9, 5))
    sns.scatterplot(data=df, x="kwh_per_sqm", y="units_kwh", hue="is_anomaly",
                    palette={False: "#8FC1D4", True: "#D1495B"}, alpha=0.6)
    plt.title("Anomalous Bills (Isolation Forest)")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "06_anomalies.png", dpi=140)
    plt.close()

    ANOMALY_PATH.parent.mkdir(exist_ok=True)
    df[df["is_anomaly"]].sort_values("units_kwh", ascending=False).to_csv(ANOMALY_PATH, index=False)
    return df
