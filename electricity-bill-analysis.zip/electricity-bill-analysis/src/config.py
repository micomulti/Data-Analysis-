"""Central configuration for the electricity bill analysis project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
REPORTS_DIR = ROOT / "reports"
FIG_DIR = REPORTS_DIR / "figures"
RAW_DATA_PATH = DATA_DIR / "bills_raw.csv"
CLEAN_DATA_PATH = DATA_DIR / "bills_clean.csv"
ANOMALY_PATH = REPORTS_DIR / "flagged_anomalies.csv"

RANDOM_STATE = 42
TEST_SIZE = 0.25

# Example tiered tariff: (upper kWh cap of tier, price per kWh). Edit to match your utility.
TARIFF_TIERS = [(100, 0.10), (200, 0.15), (float("inf"), 0.22)]
FIXED_CHARGE = 5.0
TAX_RATE = 0.075
