"""Cleaning and feature engineering."""
import pandas as pd


def season_of(month: int) -> str:
    if month in (2, 3, 4, 5):
        return "Hot"
    if month in (6, 7, 8, 9, 10):
        return "Rainy"
    return "Harmattan/Cool"


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop_duplicates().copy()
    df["month"] = pd.to_datetime(df["month"])
    df = df[(df["units_kwh"] > 0) & (df["bill_amount"] > 0)]
    num = df.select_dtypes("number").columns
    df[num] = df[num].fillna(df[num].median())
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["year"] = df["month"].dt.year
    df["month_num"] = df["month"].dt.month
    df["season"] = df["month_num"].map(season_of)
    df["cost_per_kwh"] = df["bill_amount"] / df["units_kwh"]
    df["kwh_per_person"] = df["units_kwh"] / df["household_size"]
    df["kwh_per_sqm"] = df["units_kwh"] / df["area_sqm"]
    df = df.sort_values(["household_id", "month"])
    df["prev_month_kwh"] = df.groupby("household_id")["units_kwh"].shift(1)
    df["mom_change_pct"] = (df["units_kwh"] / df["prev_month_kwh"] - 1) * 100
    return df


def prepare(df: pd.DataFrame) -> pd.DataFrame:
    return engineer_features(clean_data(df))
