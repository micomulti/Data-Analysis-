"""Synthetic household electricity dataset generator and tariff calculator."""
import numpy as np
import pandas as pd

from .config import FIXED_CHARGE, RANDOM_STATE, TARIFF_TIERS, TAX_RATE


def compute_bill(units: float) -> float:
    """Tiered tariff + fixed charge + tax."""
    remaining, cost, prev_cap = float(units), 0.0, 0
    for cap, rate in TARIFF_TIERS:
        block = min(remaining, cap - prev_cap)
        cost += block * rate
        remaining -= block
        prev_cap = cap
        if remaining <= 0:
            break
    return round((cost + FIXED_CHARGE) * (1 + TAX_RATE), 2)


def generate_synthetic_data(n_households: int = 200, start: str = "2023-01-01",
                            end: str = "2025-12-01", seed: int = RANDOM_STATE) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    months = pd.date_range(start, end, freq="MS")
    prop_types = rng.choice(["Apartment", "Duplex", "Detached House"], n_households, p=[0.5, 0.3, 0.2])
    base_area = {"Apartment": 80, "Duplex": 140, "Detached House": 220}

    homes = pd.DataFrame({
        "household_id": [f"H{i:04d}" for i in range(n_households)],
        "property_type": prop_types,
        "household_size": rng.integers(1, 8, n_households),
        "num_appliances": rng.integers(5, 25, n_households),
    })
    homes["area_sqm"] = [int(base_area[p] * rng.uniform(0.8, 1.3)) for p in homes["property_type"]]

    rows = []
    for _, h in homes.iterrows():
        for m in months:
            seasonal_temp = 27 + 6 * np.sin((m.month - 1) / 12 * 2 * np.pi - 0.5)
            temp = seasonal_temp + rng.normal(0, 1.2)
            units = (40 + 6 * h.household_size + 5 * h.num_appliances + 0.35 * h.area_sqm
                     + 4 * max(temp - 24, 0) * (h.area_sqm / 100) + rng.normal(0, 12))
            units = max(units, 20)
            if rng.random() < 0.01:  # rare faults / meter errors
                units *= rng.uniform(2, 3)
            rows.append({**h.to_dict(), "month": m, "avg_temp_c": round(temp, 1), "units_kwh": round(units, 1)})

    df = pd.DataFrame(rows)
    df["bill_amount"] = df["units_kwh"].apply(compute_bill)
    return df
