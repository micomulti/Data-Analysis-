# Electricity Bill Analysis

Analyses 3 years of monthly household electricity usage and bills.

## Business questions
- How do consumption and bills change by month and season?
- How do temperature, household size, appliances and floor area drive usage?
- Which bills look abnormal (possible faults, meter errors or theft)?
- Can we predict a household's monthly bill?

## Pipeline
1. **Load** your CSV or generate 200 households x 36 months (7,200 records).
2. **Clean**: remove duplicates and non-positive readings, parse dates.
3. **Feature engineering**: year, month, season, cost per kWh, kWh per person, kWh per m², month-over-month change.
4. **EDA**: monthly trend, seasonality, property-type comparison, temperature vs usage, correlation heatmap.
5. **Anomaly detection**: Isolation Forest flags the most unusual 1% of bills, exported to `flagged_anomalies.csv`.
6. **Prediction**: Linear Regression vs Gradient Boosting on normal bills, evaluated with R² and MAE.

## Tariff
A tiered tariff is defined at the top of the script and is easy to edit:
```python
TARIFF_TIERS = [(100, 0.10), (200, 0.15), (float("inf"), 0.22)]
FIXED_CHARGE = 5.0
TAX_RATE = 0.075
```

## Run
```bash
python electricity_bill_analysis.py                 # synthetic data
python electricity_bill_analysis.py --data bills.csv # your data
```

### Required columns for your own CSV
`household_id, month (YYYY-MM-DD), units_kwh, bill_amount, avg_temp_c, household_size, property_type, num_appliances, area_sqm`

## Outputs (`outputs/`)
`01_monthly_trend.png`, `02_seasonality_property.png`, `03_drivers.png`, `04_correlation.png`, `05_anomalies.png`, `06_prediction.png`, `07_feature_importance.png`, `cleaned_bills.csv`, `flagged_anomalies.csv`, `summary_report.txt`

## Ideas for extension
- Forecast next-month usage with Prophet or SARIMA
- Simulate savings from switching to a different tariff
- Build a Streamlit dashboard on top of `cleaned_bills.csv`
