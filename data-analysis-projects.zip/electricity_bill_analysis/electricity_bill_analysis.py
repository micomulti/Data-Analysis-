"""
Electricity Bill Analysis
=========================
Analyse household electricity consumption and billing:
  1. Load data (your own CSV, or a synthetic dataset if none is supplied)
  2. Clean and engineer features
  3. Explore consumption patterns (monthly, seasonal, by property type)
  4. Detect abnormal bills (anomaly detection)
  5. Predict the monthly bill with regression
  6. Export charts and a summary report

Usage:
    python electricity_bill_analysis.py
    python electricity_bill_analysis.py --data my_bills.csv

Expected CSV columns (for your own data):
    household_id, month (YYYY-MM-DD), units_kwh, bill_amount, avg_temp_c,
    household_size, property_type, num_appliances, area_sqm
"""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import GradientBoostingRegressor, IsolationForest
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

OUTPUT_DIR = Path("outputs")
RANDOM_STATE = 42
sns.set_theme(style="whitegrid")

# Example tiered tariff (currency per kWh) - edit to match your utility
TARIFF_TIERS = [(100, 0.10), (200, 0.15), (float("inf"), 0.22)]
FIXED_CHARGE = 5.0
TAX_RATE = 0.075


# --------------------------------------------------------------------------- #
# 1. Data loading
# --------------------------------------------------------------------------- #
def compute_bill(units: float) -> float:
    """Tiered tariff + fixed charge + tax."""
    remaining, cost, prev_cap = units, 0.0, 0
    for cap, rate in TARIFF_TIERS:
        block = min(remaining, cap - prev_cap)
        cost += block * rate
        remaining -= block
        prev_cap = cap
        if remaining <= 0:
            break
    return round((cost + FIXED_CHARGE) * (1 + TAX_RATE), 2)


def generate_synthetic_data(n_households: int = 200, seed: int = RANDOM_STATE) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    months = pd.date_range("2023-01-01", "2025-12-01", freq="MS")
    prop_types = rng.choice(["Apartment", "Duplex", "Detached House"], n_households, p=[0.5, 0.3, 0.2])
    base_area = {"Apartment": 80, "Duplex": 140, "Detached House": 220}

    homes = pd.DataFrame({
        "household_id": [f"H{i:04d}" for i in range(n_households)],
        "property_type": prop_types,
        "household_size": rng.integers(1, 8, n_households),
        "num_appliances": rng.integers(5, 25, n_households),
    })
    homes["area_sqm"] = [int(base_area[p] * rng.uniform(0.8, 1.3)) for p in homes["property_type"]]

    rows = []
    for _, h in homes.iterrows():
        for m in months:
            # Hot months (Mar-May) drive air-conditioning use
            seasonal_temp = 27 + 6 * np.sin((m.month - 1) / 12 * 2 * np.pi - 0.5)
            temp = seasonal_temp + rng.normal(0, 1.2)
            units = (40 + 6 * h.household_size + 5 * h.num_appliances + 0.35 * h.area_sqm
                     + 4 * max(temp - 24, 0) * (h.area_sqm / 100) + rng.normal(0, 12))
            units = max(units, 20)
            if rng.random() < 0.01:       # rare faults / meter errors
                units *= rng.uniform(2, 3)
            rows.append({**h.to_dict(), "month": m, "avg_temp_c": round(temp, 1),
                         "units_kwh": round(units, 1)})

    df = pd.DataFrame(rows)
    df["bill_amount"] = df["units_kwh"].apply(compute_bill)
    return df


def load_data(path: str | None) -> pd.DataFrame:
    if path:
        print(f"Loading data from {path}")
        return pd.read_csv(path, parse_dates=["month"])
    print("No CSV supplied - generating synthetic data.")
    return generate_synthetic_data()


# --------------------------------------------------------------------------- #
# 2. Cleaning & features
# --------------------------------------------------------------------------- #
def clean_and_engineer(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop_duplicates().copy()
    df["month"] = pd.to_datetime(df["month"])
    df = df[(df["units_kwh"] > 0) & (df["bill_amount"] > 0)]

    df["year"] = df["month"].dt.year
    df["month_num"] = df["month"].dt.month
    df["season"] = df["month_num"].map(
        lambda m: "Hot" if m in (2, 3, 4, 5) else ("Rainy" if m in (6, 7, 8, 9, 10) else "Harmattan/Cool"))
    df["cost_per_kwh"] = df["bill_amount"] / df["units_kwh"]
    df["kwh_per_person"] = df["units_kwh"] / df["household_size"]
    df["kwh_per_sqm"] = df["units_kwh"] / df["area_sqm"]

    df = df.sort_values(["household_id", "month"])
    df["prev_month_kwh"] = df.groupby("household_id")["units_kwh"].shift(1)
    df["mom_change_pct"] = (df["units_kwh"] / df["prev_month_kwh"] - 1) * 100
    return df


# --------------------------------------------------------------------------- #
# 3. EDA
# --------------------------------------------------------------------------- #
def run_eda(df: pd.DataFrame) -> None:
    # Monthly trend
    monthly = df.groupby("month")[["units_kwh", "bill_amount"]].mean()
    fig, ax1 = plt.subplots(figsize=(12, 4.5))
    ax1.plot(monthly.index, monthly["units_kwh"], color="#2E86AB", marker="o", ms=3, label="Avg kWh")
    ax1.set_ylabel("Average kWh", color="#2E86AB")
    ax2 = ax1.twinx()
    ax2.plot(monthly.index, monthly["bill_amount"], color="#D1495B", marker="s", ms=3, label="Avg bill")
    ax2.set_ylabel("Average bill", color="#D1495B")
    ax2.grid(False)
    plt.title("Average Monthly Consumption and Bill")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "01_monthly_trend.png", dpi=150)
    plt.close()

    # Seasonality + property type
    fig, axes = plt.subplots(1, 2, figsize=(14, 4.8))
    sns.boxplot(data=df, x="month_num", y="units_kwh", color="#8FC1D4", ax=axes[0])
    axes[0].set_title("Consumption by Calendar Month")
    axes[0].set_xlabel("Month")
    sns.boxplot(data=df, x="property_type", y="bill_amount", hue="property_type", palette="Set2", legend=False, ax=axes[1])
    axes[1].set_title("Bill Amount by Property Type")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "02_seasonality_property.png", dpi=150)
    plt.close()

    # Temperature and household size drivers
    fig, axes = plt.subplots(1, 2, figsize=(14, 4.8))
    sns.scatterplot(data=df.sample(min(3000, len(df)), random_state=1), x="avg_temp_c",
                    y="units_kwh", hue="property_type", alpha=0.5, ax=axes[0])
    axes[0].set_title("Temperature vs Consumption")
    sns.barplot(data=df, x="household_size", y="units_kwh", color="#EDAE49", ax=axes[1])
    axes[1].set_title("Average kWh by Household Size")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "03_drivers.png", dpi=150)
    plt.close()

    # Correlation
    cols = ["units_kwh", "bill_amount", "avg_temp_c", "household_size",
            "num_appliances", "area_sqm", "cost_per_kwh"]
    plt.figure(figsize=(8, 6.5))
    sns.heatmap(df[cols].corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Correlation Matrix")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "04_correlation.png", dpi=150)
    plt.close()


# --------------------------------------------------------------------------- #
# 4. Anomaly detection
# --------------------------------------------------------------------------- #
def detect_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    feats = ["units_kwh", "kwh_per_sqm", "kwh_per_person", "avg_temp_c"]
    iso = IsolationForest(contamination=0.01, random_state=RANDOM_STATE)
    df = df.copy()
    df["is_anomaly"] = iso.fit_predict(df[feats]) == -1

    plt.figure(figsize=(9, 5))
    sns.scatterplot(data=df, x="kwh_per_sqm", y="units_kwh", hue="is_anomaly",
                    palette={False: "#8FC1D4", True: "#D1495B"}, alpha=0.6)
    plt.title("Anomalous Bills (Isolation Forest)")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "05_anomalies.png", dpi=150)
    plt.close()

    df[df["is_anomaly"]].sort_values("units_kwh", ascending=False).to_csv(
        OUTPUT_DIR / "flagged_anomalies.csv", index=False)
    return df


# --------------------------------------------------------------------------- #
# 5. Bill prediction
# --------------------------------------------------------------------------- #
def predict_bill(df: pd.DataFrame) -> dict:
    df = df[~df["is_anomaly"]]  # train on normal bills only
    features = ["avg_temp_c", "household_size", "num_appliances", "area_sqm", "month_num"]
    X = pd.get_dummies(df[features + ["property_type"]], columns=["property_type"], drop_first=True)
    y = df["bill_amount"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=RANDOM_STATE)

    models = {
        "Linear Regression": LinearRegression(),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=250, max_depth=3,
                                                       learning_rate=0.08, random_state=RANDOM_STATE),
    }
    results = {}
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, (name, model) in zip(axes, models.items()):
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        results[name] = {"r2": r2_score(y_test, pred), "mae": mean_absolute_error(y_test, pred)}
        ax.scatter(y_test, pred, alpha=0.3, s=10, color="#2E86AB")
        lims = [y_test.min(), y_test.max()]
        ax.plot(lims, lims, "r--")
        ax.set_title(f"{name}\nR2={results[name]['r2']:.3f}, MAE={results[name]['mae']:.2f}")
        ax.set_xlabel("Actual bill")
        ax.set_ylabel("Predicted bill")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "06_prediction.png", dpi=150)
    plt.close()

    imp = pd.Series(models["Gradient Boosting"].feature_importances_, index=X.columns).sort_values()
    imp.plot.barh(figsize=(8, 4.5), color="#2E86AB")
    plt.title("Feature Importance (Gradient Boosting)")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "07_feature_importance.png", dpi=150)
    plt.close()
    return results


# --------------------------------------------------------------------------- #
# 6. Report
# --------------------------------------------------------------------------- #
def write_report(df: pd.DataFrame, results: dict) -> None:
    peak = df.groupby("month_num")["units_kwh"].mean().idxmax()
    low = df.groupby("month_num")["units_kwh"].mean().idxmin()
    lines = [
        "ELECTRICITY BILL ANALYSIS - SUMMARY REPORT",
        "=" * 44,
        f"Records analysed        : {len(df):,}",
        f"Households              : {df['household_id'].nunique():,}",
        f"Period                  : {df['month'].min():%b %Y} to {df['month'].max():%b %Y}",
        f"Average monthly usage   : {df['units_kwh'].mean():.1f} kWh",
        f"Average monthly bill    : {df['bill_amount'].mean():.2f}",
        f"Peak month (avg usage)  : month {peak}",
        f"Lowest month (avg usage): month {low}",
        f"Anomalous bills flagged : {int(df['is_anomaly'].sum())}",
        "",
        "Average bill by property type:",
        df.groupby("property_type")["bill_amount"].mean().round(2).to_string(),
        "",
        "Average usage by season (kWh):",
        df.groupby("season")["units_kwh"].mean().round(1).to_string(),
        "",
        "Bill prediction models:",
    ]
    for name, r in results.items():
        lines.append(f"  {name:<20} R2 = {r['r2']:.3f} | MAE = {r['mae']:.2f}")
    (OUTPUT_DIR / "summary_report.txt").write_text("\n".join(lines))
    print("\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser(description="Electricity bill analysis")
    parser.add_argument("--data", help="Path to an electricity bills CSV file")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(exist_ok=True)
    df = clean_and_engineer(load_data(args.data))
    run_eda(df)
    df = detect_anomalies(df)
    results = predict_bill(df)
    df.to_csv(OUTPUT_DIR / "cleaned_bills.csv", index=False)
    write_report(df, results)
    print(f"\nCharts and report saved to: {OUTPUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
