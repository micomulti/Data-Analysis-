# Bank Loan Analysis

Analyses loan applications to find which factors drive default and builds models to predict it.

## Business questions
- What is the overall default rate, and how does it vary by credit band, loan purpose, home ownership and education?
- Which factors (credit score, debt-to-income, interest rate, etc.) matter most?
- Can we reliably flag high-risk applicants before approving a loan?

## Pipeline
1. **Load** your CSV or generate 5,000 synthetic loans (with injected missing values).
2. **Clean**: remove duplicates, impute numeric values with the median and categorical with the mode.
3. **Feature engineering**: debt-to-income, loan-to-income, monthly payment (amortisation formula), payment-to-income, credit band, age group.
4. **EDA**: outcome overview, default rate by category, distributions by outcome, correlation heatmap.
5. **Modelling**: Logistic Regression vs Random Forest (stratified 75/25 split, balanced class weights), evaluated with ROC-AUC, precision/recall and a confusion matrix.

## Run
```bash
python bank_loan_analysis.py                  # synthetic data
python bank_loan_analysis.py --data loans.csv # your data
```

### Required columns for your own CSV
`age, income, loan_amount, loan_term_months, interest_rate, credit_score, employment_years, existing_debt, education, home_ownership, loan_purpose, default` (1 = defaulted, 0 = repaid)

## Outputs (`outputs/`)
`01_default_overview.png`, `02_default_by_category.png`, `03_distributions.png`, `04_correlation.png`, `05_roc_curves.png`, `06_confusion_matrix.png`, `07_feature_importance.png`, `cleaned_loans.csv`, `summary_report.txt`

## Ideas for extension
- Tune hyperparameters with `GridSearchCV`
- Add SHAP explanations for individual decisions
- Adjust the decision threshold using the cost of a missed default vs a rejected good customer
- Check model fairness across age groups
