"""
Bank Loan Analysis
==================
End-to-end analysis of loan applications:
  1. Load data (your own CSV, or a synthetic dataset if none is supplied)
  2. Clean and engineer features
  3. Exploratory data analysis (EDA) with saved charts
  4. Predict loan default with Logistic Regression and Random Forest
  5. Export a summary report

Usage:
    python bank_loan_analysis.py                    # uses synthetic data
    python bank_loan_analysis.py --data my_loans.csv

Expected CSV columns (for your own data):
    age, income, loan_amount, loan_term_months, interest_rate, credit_score,
    employment_years, existing_debt, education, home_ownership, loan_purpose,
    default   (1 = defaulted, 0 = repaid)
"""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, classification_report,
                             roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

OUTPUT_DIR = Path("outputs")
RANDOM_STATE = 42
sns.set_theme(style="whitegrid")


# --------------------------------------------------------------------------- #
# 1. Data loading
# --------------------------------------------------------------------------- #
def generate_synthetic_data(n: int = 5000, seed: int = RANDOM_STATE) -> pd.DataFrame:
    """Create a realistic synthetic loan dataset."""
    rng = np.random.default_rng(seed)

    age = rng.integers(21, 70, n)
    income = rng.lognormal(mean=10.8, sigma=0.5, size=n).round(2)
    credit_score = np.clip(rng.normal(680, 70, n), 300, 850).round().astype(int)
    employment_years = np.clip(age - 21 - rng.integers(0, 10, n), 0, 45)
    existing_debt = (income * rng.uniform(0, 0.8, n)).round(2)
    loan_amount = (income * rng.uniform(0.3, 3.0, n)).round(2)
    loan_term = rng.choice([12, 24, 36, 48, 60, 84], n)
    interest_rate = np.clip(22 - (credit_score - 300) / 30 + rng.normal(0, 1.5, n), 3, 30).round(2)

    df = pd.DataFrame({
        "age": age,
        "income": income,
        "loan_amount": loan_amount,
        "loan_term_months": loan_term,
        "interest_rate": interest_rate,
        "credit_score": credit_score,
        "employment_years": employment_years,
        "existing_debt": existing_debt,
        "education": rng.choice(["High School", "Bachelor", "Master", "PhD"], n, p=[0.35, 0.4, 0.2, 0.05]),
        "home_ownership": rng.choice(["Rent", "Mortgage", "Own"], n, p=[0.45, 0.4, 0.15]),
        "loan_purpose": rng.choice(["Debt Consolidation", "Home Improvement", "Business",
                                    "Education", "Car", "Medical"], n),
    })

    # Default probability driven by realistic risk factors
    dti = existing_debt / income
    lti = loan_amount / income
    logit = (-3.3
             - 0.012 * (credit_score - 650)
             + 2.0 * dti
             + 0.9 * lti
             - 0.03 * employment_years
             + 0.04 * (interest_rate - 12)
             + rng.normal(0, 0.5, n))
    prob = 1 / (1 + np.exp(-logit))
    df["default"] = (rng.random(n) < prob).astype(int)

    # Inject some missing values to practise cleaning
    for col in ["income", "credit_score", "employment_years"]:
        df.loc[rng.choice(n, int(n * 0.02), replace=False), col] = np.nan
    return df


def load_data(path: str | None) -> pd.DataFrame:
    if path:
        print(f"Loading data from {path}")
        return pd.read_csv(path)
    print("No CSV supplied - generating synthetic data.")
    return generate_synthetic_data()


# --------------------------------------------------------------------------- #
# 2. Cleaning & feature engineering
# --------------------------------------------------------------------------- #
def clean_and_engineer(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop_duplicates().copy()

    num_cols = df.select_dtypes(include="number").columns.drop("default")
    cat_cols = df.select_dtypes(exclude="number").columns
    df[num_cols] = df[num_cols].fillna(df[num_cols].median())
    df[cat_cols] = df[cat_cols].fillna(df[cat_cols].mode().iloc[0])

    # Business ratios used by credit analysts
    df["debt_to_income"] = df["existing_debt"] / df["income"]
    df["loan_to_income"] = df["loan_amount"] / df["income"]
    r = df["interest_rate"] / 1200  # monthly rate
    n = df["loan_term_months"]
    df["monthly_payment"] = df["loan_amount"] * r / (1 - (1 + r) ** (-n))
    df["payment_to_income"] = df["monthly_payment"] * 12 / df["income"]

    df["credit_band"] = pd.cut(df["credit_score"], [0, 580, 670, 740, 800, 900],
                               labels=["Poor", "Fair", "Good", "Very Good", "Excellent"])
    df["age_group"] = pd.cut(df["age"], [0, 30, 40, 50, 60, 100],
                             labels=["<30", "30-39", "40-49", "50-59", "60+"])
    return df


# --------------------------------------------------------------------------- #
# 3. EDA
# --------------------------------------------------------------------------- #
def run_eda(df: pd.DataFrame) -> dict:
    OUTPUT_DIR.mkdir(exist_ok=True)
    stats = {"rows": len(df), "default_rate": df["default"].mean()}

    # Default rate overview + credit-band risk
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    df["default"].value_counts().rename({0: "Repaid", 1: "Default"}).plot.bar(
        ax=axes[0], color=["#4C9F70", "#D1495B"], rot=0)
    axes[0].set_title("Loan Outcomes")
    axes[0].set_ylabel("Number of loans")
    (df.groupby("credit_band", observed=True)["default"].mean() * 100).plot.bar(
        ax=axes[1], color="#EDAE49", rot=0)
    axes[1].set_title("Default Rate by Credit Band")
    axes[1].set_ylabel("Default rate (%)")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "01_default_overview.png", dpi=150)
    plt.close()

    # Default rate by category
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
    for ax, col in zip(axes, ["loan_purpose", "home_ownership", "education"]):
        (df.groupby(col)["default"].mean() * 100).sort_values().plot.barh(ax=ax, color="#2E86AB")
        ax.set_title(f"Default Rate by {col.replace('_', ' ').title()}")
        ax.set_xlabel("Default rate (%)")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "02_default_by_category.png", dpi=150)
    plt.close()

    # Distributions split by outcome
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
    for ax, col in zip(axes, ["credit_score", "debt_to_income", "interest_rate"]):
        sns.kdeplot(data=df, x=col, hue="default", fill=True, common_norm=False,
                    palette=["#4C9F70", "#D1495B"], ax=ax)
        ax.set_title(f"{col.replace('_', ' ').title()} by Outcome")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "03_distributions.png", dpi=150)
    plt.close()

    # Correlation heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(df.select_dtypes("number").corr(), annot=True, fmt=".2f",
                cmap="coolwarm", center=0, annot_kws={"size": 7})
    plt.title("Correlation Matrix")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "04_correlation.png", dpi=150)
    plt.close()

    return stats


# --------------------------------------------------------------------------- #
# 4. Modelling
# --------------------------------------------------------------------------- #
def train_models(df: pd.DataFrame) -> dict:
    features = df.drop(columns=["default", "credit_band", "age_group"])
    y = df["default"]
    num = features.select_dtypes("number").columns.tolist()
    cat = features.select_dtypes(exclude="number").columns.tolist()

    X_train, X_test, y_train, y_test = train_test_split(
        features, y, test_size=0.25, stratify=y, random_state=RANDOM_STATE)

    pre = ColumnTransformer([
        ("num", StandardScaler(), num),
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat),
    ])
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=8, min_samples_leaf=10,
                                                class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1),
    }

    results, fitted = {}, {}
    plt.figure(figsize=(6.5, 5.5))
    for name, model in models.items():
        pipe = Pipeline([("prep", pre), ("model", model)]).fit(X_train, y_train)
        proba = pipe.predict_proba(X_test)[:, 1]
        pred = pipe.predict(X_test)
        auc = roc_auc_score(y_test, proba)
        results[name] = {"auc": auc, "report": classification_report(y_test, pred, digits=3)}
        fitted[name] = (pipe, pred)
        fpr, tpr, _ = roc_curve(y_test, proba)
        plt.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})")
    plt.plot([0, 1], [0, 1], "k--", alpha=0.5)
    plt.xlabel("False positive rate")
    plt.ylabel("True positive rate")
    plt.title("ROC Curves")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "05_roc_curves.png", dpi=150)
    plt.close()

    # Confusion matrix of the best model
    best = max(results, key=lambda k: results[k]["auc"])
    ConfusionMatrixDisplay.from_predictions(y_test, fitted[best][1], cmap="Blues",
                                            display_labels=["Repaid", "Default"])
    plt.title(f"Confusion Matrix - {best}")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "06_confusion_matrix.png", dpi=150)
    plt.close()

    # Feature importance from random forest
    rf_pipe = fitted["Random Forest"][0]
    names = rf_pipe["prep"].get_feature_names_out()
    imp = pd.Series(rf_pipe["model"].feature_importances_, index=names).sort_values().tail(12)
    imp.plot.barh(figsize=(8, 5), color="#2E86AB")
    plt.title("Top 12 Feature Importances (Random Forest)")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "07_feature_importance.png", dpi=150)
    plt.close()

    results["best_model"] = best
    return results


# --------------------------------------------------------------------------- #
# 5. Report
# --------------------------------------------------------------------------- #
def write_report(stats: dict, results: dict, df: pd.DataFrame) -> None:
    lines = [
        "BANK LOAN ANALYSIS - SUMMARY REPORT",
        "=" * 40,
        f"Loans analysed      : {stats['rows']:,}",
        f"Overall default rate: {stats['default_rate']:.1%}",
        f"Average loan amount : {df['loan_amount'].mean():,.0f}",
        f"Average credit score: {df['credit_score'].mean():.0f}",
        "",
        "Default rate by credit band:",
        (df.groupby("credit_band", observed=True)["default"].mean() * 100).round(1).to_string(),
        "",
        f"Best model: {results['best_model']}",
    ]
    for name in ["Logistic Regression", "Random Forest"]:
        lines += ["", f"--- {name} (ROC-AUC {results[name]['auc']:.3f}) ---", results[name]["report"]]
    (OUTPUT_DIR / "summary_report.txt").write_text("\n".join(lines))
    print("\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser(description="Bank loan default analysis")
    parser.add_argument("--data", help="Path to a loan CSV file")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(exist_ok=True)
    raw = load_data(args.data)
    df = clean_and_engineer(raw)
    df.to_csv(OUTPUT_DIR / "cleaned_loans.csv", index=False)
    stats = run_eda(df)
    results = train_models(df)
    write_report(stats, results, df)
    print(f"\nCharts and report saved to: {OUTPUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
