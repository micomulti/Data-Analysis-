# Data Analysis Projects

Two end-to-end data analysis projects in Python, each runnable with a single command.
Both generate a realistic synthetic dataset by default, so they work out of the box,
and both accept your own CSV via `--data`.

| Project | Goal | Techniques |
|---|---|---|
| [Bank Loan Analysis](bank_loan_analysis/) | Understand and predict loan default risk | Cleaning, ratio features, EDA, Logistic Regression, Random Forest, ROC-AUC |
| [Electricity Bill Analysis](electricity_bill_analysis/) | Understand consumption drivers, flag unusual bills, predict bills | Tariff modelling, seasonality, Isolation Forest, Regression |

## Quick start

```bash
git clone <your-repo-url>
cd data-analysis-projects
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python bank_loan_analysis/bank_loan_analysis.py
python electricity_bill_analysis/electricity_bill_analysis.py
```

Each script writes charts, a cleaned CSV, and `summary_report.txt` to an `outputs/` folder
in the directory you run it from.

## Project structure

```
data-analysis-projects/
├── README.md
├── requirements.txt
├── .gitignore
├── bank_loan_analysis/
│   ├── README.md
│   └── bank_loan_analysis.py
└── electricity_bill_analysis/
    ├── README.md
    └── electricity_bill_analysis.py
```

## Note on data

The built-in datasets are synthetic, so findings illustrate the method, not real-world facts.
For genuine insights, supply your own data (column requirements are in each project README).
